<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string($_POST["name"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $message = $conn->real_escape_string($_POST["message"]);
    $created_at = date("Y-m-d H:i:s");

    $sql = "INSERT INTO contact_messages (name, email, message, created_at) VALUES ('$name', '$email', '$message', '$created_at')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Your contact is submitted!'); window.location.href='index.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.history.back();</script>";
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Foodies</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #181818;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: white;
            flex-direction: column;
        }

        .back-btn {
    position: absolute;
    top: 20px;
    left: 20px;
    background: #333;
    color: white;
    border: none;
    padding: 4px 8px; /* Mas maliit na padding */
    width: 70px; /* Fixed width para hindi humaba */
    text-align: center;
    border-radius: 5px;
    cursor: pointer;
    font-size: 12px; /* Mas maliit na font-size */
    transition: 0.3s ease;
}


        .back-btn:hover {
            background: #ffa31a;
            color: black;
        }

        .contact-container {
            background: #212121;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            width: 400px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            color: #ffa31a;
        }

        .input-group {
            margin: 15px 0;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            outline: none;
            background: #333;
            color: white;
        }

        textarea {
            height: 100px;
            resize: none;
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            background: #ffa31a;
            color: black;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s ease;
        }

        button:hover {
            background: #ff7b00;
        }

        #overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
        }

        .success-modal {
            background: #333;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .close-btn {
            background: #ffa31a;
            color: black;
            border: none;
            padding: 10px 15px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .close-btn:hover {
            background: #ff7b00;
        }
    </style>
</head>
<body>
    <!-- Back Button -->
    <button class="back-btn" onclick="goBack()">← Back</button>

    <div class="contact-container">
        <h2>Contact</h2>
        <form action="" method="POST">
            <div class="input-group">
                <input type="text" name="name" placeholder="Your Name" required>
            </div>
            <div class="input-group">
                <input type="email" name="email" placeholder="Your Email" required>
            </div>
            <div class="input-group">
                <textarea name="message" placeholder="Your Message" required></textarea>
            </div>
            <button type="submit">Send Message</button>
        </form>
    </div>

    <!-- Remove the overlay/modal, as we now use JS alert and redirect -->

    <script>
        function goBack() {
            window.history.back();
        }

        // Remove the closeModal function as it's no longer needed
    </script>
</body>
</html>
