<?php
session_start();

// Check if cart has items
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: menu.php");
    exit();
}

// Optional: You can insert the order into your database here (if you have order tables)

// Clear the cart after processing
unset($_SESSION['cart']);

// Redirect to thank you page with payment method
header("Location: thank_you.php?method=cash");
exit();
?>
