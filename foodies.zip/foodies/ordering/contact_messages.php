<?php
include 'config.php';
$result = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Messages - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
    <style>
        body {
            background: #181818;
            color: #fff;
            font-family: 'Poppins', Arial, sans-serif;
        }
        .container {
            margin-top: 40px;
            background: #232323;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }
        h2 {
            color: #ffa31a;
            margin-bottom: 25px;
        }
        table {
            background: #232323;
            color: #fff;
        }
        th {
            background: #ffa31a;
            color: #181818;
        }
        tr:nth-child(even) {
            background: #292929;
        }
        .btn-back {
            background: #ffa31a;
            color: #181818;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-decoration: none;
            font-weight: bold;
        }
        .btn-back:hover {
            background: #ff8c00;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="admin.php" class="btn-back">&larr; Back to Dashboard</a>
        <h2>Contact Messages</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Message</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['id']) ?></td>
                                <td><?= htmlspecialchars($row['name']) ?></td>
                                <td><?= htmlspecialchars($row['email']) ?></td>
                                <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
                                <td><?= htmlspecialchars($row['created_at']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center">No contact messages found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?> 