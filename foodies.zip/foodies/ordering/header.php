<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php'; // database connection

$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job & Grab - Header</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Nunito', sans-serif; }

        .header {
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .logo .job {
            background: black;
            color: white;
            padding: 3px 8px;
            border-radius: 5px;
        }

        .logo .grab {
            background: rgb(255, 166, 0);
            color: white;
            padding: 3px 8px;
            border-radius: 5px;
        }

        .nav-links {
            display: flex;
            gap: 15px;
            list-style: none;
        }

        .nav-links a {
            color: white;
            background-color: rgba(255, 166, 0, 0.1);
            padding: 8px 16px;
            border: 2px solid rgb(255, 166, 0);
            border-radius: 8px;
            text-decoration: none;
            font-size: 16px;
            font-weight: 600;
            transition: background-color 0.3s, transform 0.2s;
        }

        .nav-links a:hover {
            background-color: rgb(255, 166, 0);
            color: black;
            transform: translateY(-2px);
        }

        .icon-button {
            display: flex;
            align-items: center;
            background: white;
            color: rgb(255, 166, 0);
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            position: relative;
            margin-left: 10px;
        }

        .icon-button .icon {
            margin-right: 6px;
        }

        .icon-badge {
            background: red;
            color: white;
            font-size: 12px;
            font-weight: bold;
            border-radius: 50%;
            padding: 4px 8px;
            position: absolute;
            top: -5px;
            right: -5px;
        }

        .auth-buttons {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .auth-buttons a.logout {
            padding: 8px 15px;
            background: white;
            color: #FF6F61;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
            cursor: pointer;
        }

        .auth-buttons a.logout:hover {
            background: #fff;
        }

        .menu-toggle {
            display: none;
            font-size: 24px;
            cursor: pointer;
        }

        @media (max-width: 768px) {
            .nav-links {
                display: none;
                flex-direction: column;
                background: #FF6F61;
                position: absolute;
                top: 60px;
                left: 0;
                width: 100%;
                padding: 10px 0;
                text-align: center;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            }

            .nav-links.active {
                display: flex;
            }

            .menu-toggle {
                display: block;
                color: white;
            }

            .auth-buttons {
                flex-direction: column;
                align-items: flex-end;
            }
        }
    </style>
</head>
<body>

<header class="header">
    <div class="logo">
        <span class="job">Job</span><span class="grab">& Grab</span>
    </div>

    <nav>
        <ul class="nav-links" id="navLinks">
            <li><a href="index.php">Home</a></li>
            <li><a href="menu.php">Menu</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>

    <div class="auth-buttons">
        <!-- Cart Button -->
        <a href="cart.php" class="icon-button">
            <span class="icon">🛒</span> 
            <span class="icon-badge"><?= $cart_count ?></span>
        </a>

        <!-- Login / Logout Button -->
        <?php if (isset($_SESSION['username']) && !empty($_SESSION['username'])): ?>
            <a href="#" class="logout" onclick="logoutUser()">Logout</a>
        <?php else: ?>
            <a href="logout.php" class="logout">Logout</a>
        <?php endif; ?>
    </div>

    <div class="menu-toggle" onclick="toggleMenu()">☰</div>
</header>

<script>
    function toggleMenu() {
        document.getElementById('navLinks').classList.toggle('active');
    }

    function logoutUser() {
        if (confirm("Are you sure you want to log out?")) {
            fetch("logout.php", { method: "POST" })
                .then(() => window.location.href = "login.php")
                .catch(error => console.error("Logout failed:", error));
        }
    }
</script>

</body>
</html>
