<?php
session_start();

// Sample logic: Clear the cart after processing payment
if (isset($_SESSION['cart'])) {
    unset($_SESSION['cart']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Confirmation</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: url("imahe/mama.jpg") no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        .confirmation-container {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(255, 102, 0, 0.5);
            max-width: 400px;
            width: 100%;
        }
        .confirmation-container h2 {
            color: #ff8800;
            margin-bottom: 20px;
        }
        .confirmation-container p {
            margin-bottom: 30px;
        }
        .confirmation-container button {
            padding: 12px 20px;
            background-color: #ff8800;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: 0.3s;
        }
        .confirmation-container button:hover {
            background-color: #ff6600;
        }
    </style>
</head>
<body>

<div class="confirmation-container">
    <h2>Payment Successful!</h2>
    <p>Thank you for your payment. Your order is being processed.</p>
    <button onclick="window.location.href='menu.php'">Back to Menu</button>
</div>

</body>
</html>
