<?php
session_start();
$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total_price = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Receipt</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<style>
    body {
        font-family: 'Poppins', sans-serif;
        background: url("imahe/mama.jpg") no-repeat center center fixed;
        background-size: cover;
        color: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .main-wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 30px;
    }
    .receipt-container {
        background-color: rgba(0, 0, 0, 0.85);
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(255, 136, 0, 0.5);
        padding: 40px;
        max-width: 600px;
        width: 100%;
        box-sizing: border-box;
        transition: transform 0.3s;
    }
    .receipt-container:hover {
        transform: scale(1.02);
    }
    .receipt-container h2 {
        color: #ff8800;
        font-weight: 600;
        margin-bottom: 10px;
        text-align: center;
        font-size: 28px;
        text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.7);
    }
    .receipt-container h3 {
        margin-bottom: 20px;
        text-align: center;
        font-size: 20px;
        color: #fff;
    }
    .receipt-container table {
        width: 100%;
        color: #ddd;
        margin-bottom: 15px;
        border-collapse: collapse;
    }
    .receipt-container th, .receipt-container td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #444;
    }
    .receipt-container th {
        color: #ff8800;
        font-size: 16px;
    }
    .total {
        font-size: 20px;
        font-weight: bold;
        color: #ff8800;
        margin-top: 20px;
        text-align: right;
    }
    .button-group {
        display: flex;
        flex-direction: column;
        gap: 15px;
        margin-top: 20px;
    }
    .button-group button {
        padding: 12px 20px;
        background-color: #ff8800;
        color: #fff;
        font-size: 18px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
        width: 200px;
        box-shadow: 0 4px 10px rgba(255, 136, 0, 0.3);
        font-weight: 500;
    }
    .button-group button:hover {
        background-color: #ff6600;
        box-shadow: 0 6px 15px rgba(255, 136, 0, 0.5);
    }
    /* Modal styles */
    #gcashModal {
        display: none;
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background-color: rgba(0, 0, 0, 0.8);
        z-index: 9999;
        justify-content: center;
        align-items: center;
    }
    .modal-content {
        background-color: #1a1a1a;
        padding: 20px;
        border-radius: 10px;
        text-align: center;
        max-width: 400px;
        box-shadow: 0 0 15px rgba(255, 136, 0, 0.5);
    }
    .modal-content img {
        max-width: 100%;
        border: 2px solid #ff8800;
        border-radius: 8px;
        margin-bottom: 10px;
    }
    .modal-content h3 {
        color: #ff8800;
        font-size: 24px;
        margin-bottom: 10px;
    }
    .modal-content p {
        color: #fff;
        margin: 5px 0;
    }
    @media print {
        body {
            background-color: #fff;
            color: #000;
            display: block;
            text-align: left;
        }
        .main-wrapper {
            display: block;
        }
        .button-group, #gcashModal {
            display: none;
        }
        .receipt-container {
            box-shadow: none;
            padding: 15px;
            margin: 0;
        }
    }
</style>
</head>
<body>
<div class="main-wrapper">
    <div class="receipt-container">
        <h2>Order Receipt</h2>
        <h3>Thank you for your order!</h3>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!empty($cart_items)): ?>
                <?php foreach ($cart_items as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td>₱<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                    </tr>
                    <?php $total_price += $item['price'] * $item['quantity']; ?>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="3">Your cart is empty.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        <div class="total">Total: ₱<?= number_format($total_price, 2) ?></div>
    </div>

    <div class="button-group">
        <button onclick="window.location.href='process_cash_payment.php'">PAY CASH</button>
        <button onclick="document.getElementById('gcashModal').style.display='flex'">PAY via GCash</button>
        <button onclick="window.print()">Print Receipt</button>
    </div>
</div>

<!-- GCash Modal -->
<div id="gcashModal">
    <div class="modal-content">
        <h3>GCash Payment</h3>
        <img src="imahe/jojo.jpg" alt="GCash QR Code">
        <p><strong>Mobile No.:</strong> 096•••••699</p>
        <p><strong>Account Name:</strong> NE**E N.</p>
        <p><strong>User ID:</strong> ............5103DK</p>
        <p style="margin-bottom:15px;">Transfer fees may apply.</p>
        <button onclick="confirmGCash()">Confirm Paid</button>
        <br><br>
        <button onclick="document.getElementById('gcashModal').style.display='none'">Cancel</button>
    </div>
</div>

<script>
function confirmGCash() {
    alert("Thank you! Your GCash payment is being processed.");
    window.location.href = "process_gcash_payment.php";
}
</script>

</body>
</html>
