<?php
session_start();
include 'config.php';
$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total_price = 0;
$user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($user_id) {
        // Fetch cart items from DB for this user
        $cart_query = $conn->prepare("SELECT menu_id, quantity FROM cart WHERE user_id = ?");
        $cart_query->bind_param("i", $user_id);
        $cart_query->execute();
        $cart_result = $cart_query->get_result();
        $cart_db_items = [];
        $order_total = 0;
        while ($row = $cart_result->fetch_assoc()) {
            // Get price from menu table
            $menu_query = $conn->prepare("SELECT price FROM menu WHERE id = ?");
            $menu_query->bind_param("i", $row['menu_id']);
            $menu_query->execute();
            $menu_result = $menu_query->get_result();
            $menu = $menu_result->fetch_assoc();
            $price = $menu ? floatval($menu['price']) : 0;
            $order_total += $price * $row['quantity'];
            $cart_db_items[] = [
                'menu_id' => $row['menu_id'],
                'quantity' => $row['quantity'],
                'price' => $price
            ];
            $menu_query->close();
        }
        $cart_query->close();
        if (!empty($cart_db_items)) {
            // Get a valid restaurant_id
            $restaurant_id = 1;
            $res = $conn->query("SELECT id FROM restaurants LIMIT 1");
            if ($res && $row = $res->fetch_assoc()) {
                $restaurant_id = $row['id'];
            }
            // Insert order into orders table
            $stmt = $conn->prepare("INSERT INTO orders (user_id, restaurant_id, total_price) VALUES (?, ?, ?)");
            $stmt->bind_param("iid", $user_id, $restaurant_id, $order_total);
            $stmt->execute();
            $order_id = $stmt->insert_id;
            $stmt->close();
            // Optionally, insert order items into a separate table
            // Clear cart in DB
            $clear = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
            $clear->bind_param("i", $user_id);
            $clear->execute();
            $clear->close();
            // Clear session cart
            unset($_SESSION['cart']);
            header("Location: receipt.php");
            exit;
        }
    } else {
        // Fallback: session cart only (guest)
        header("Location: receipt.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - PHub Style</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: url("imahe/mama.jpg") no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .checkout-container {
            background-color: rgba(0, 0, 0, 0.8);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(255, 102, 0, 0.3);
            padding: 30px;
            max-width: 600px;
            width: 100%;
            box-sizing: border-box;
            text-align: center;
        }
        .checkout-container h2 {
            color: #ff8800;
            font-weight: 600;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #ff8800;
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background-color: #ff6600;
        }
        .order-summary {
            margin-top: 20px;
            border-top: 1px solid #444;
            padding-top: 20px;
        }
        .order-summary h3 {
            color: #ff8800;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            color: #ddd;
            margin-bottom: 15px;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #444;
        }
        th {
            color: #ff8800;
        }
    </style>
</head>
<body>
<div class="checkout-container">
    <h2>Checkout</h2>
    <form action="checkout.php" method="POST">
        <div class="order-summary">
            <h3>Order Summary</h3>
            <table>
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($cart_items)): ?>
                        <?php foreach ($cart_items as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['name']) ?></td>
                                <td><?= $item['quantity'] ?></td>
                                <td>₱<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                            </tr>
                            <?php $total_price += $item['price'] * $item['quantity']; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">Your cart is empty.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <h3>Total: ₱<?= number_format($total_price, 2) ?></h3>
        </div>
        <button type="submit">Place Order</button>
    </form>
</div>
</body>
</html>
