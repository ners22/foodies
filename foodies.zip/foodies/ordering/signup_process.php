<?php
// Start session
session_start();

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Include the database connection file
include('config.php'); // Make sure this file connects to the database via PDO

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data        
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Input validation (basic)
    if (empty($username) || empty($password)) {
        echo "Please fill in all fields.";
        exit;
    }

    // Check if the username already exists
    $sql = "SELECT * FROM users WHERE username = :username"; // Using named parameter
    $stmt = $conn->prepare($sql); // PDO prepare method

    // Bind the username parameter (using PDO's bindValue for named parameters)
    $stmt->bindValue(':username', $username, PDO::PARAM_STR);
    $stmt->execute(); // Execute the query

    // Fetch all results
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // PDO fetch method

    if (count($result) > 0) {
        // If username already exists, show an error message
        echo "Username already taken. Please choose another one.";
    } else {
        // Hash the password before storing it in the database
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert the new user into the database
        $sql = "INSERT INTO users (username, password) VALUES (:username, :password)";
        $stmt = $conn->prepare($sql); // Prepare insert query

        // Bind the parameters for the insert statement
        $stmt->bindValue(':username', $username, PDO::PARAM_STR);
        $stmt->bindValue(':password', $hashed_password, PDO::PARAM_STR);
        $stmt->execute(); // Execute the insert statement

        // Check if the query was successful
        if ($stmt->rowCount() > 0) {
            // Redirect to the login page after successful registration
            header("Location: home_page.php");
            exit();
        } else {
            echo "An error occurred while inserting the user. Please try again.";
        }
    }

    // Close the prepared statement
    $stmt = null;
}

// Close the database connection
$conn = null;
?>
