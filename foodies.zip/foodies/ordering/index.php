<?php
// Start session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job & Grab - Home</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body {
        font-family: 'Poppins', sans-serif;
        background: url("imahe/mama.jpg") no-repeat center center fixed;
        background-size: cover;
        background-attachment: fixed;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    .container {
        flex: 1;
        padding: 20px;
    }

    .welcome-message {
        text-align: center;
        margin-top: 30px;
        padding: 20px;
        border-radius: 10px;
        width: 90%;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
        background: rgba(0, 0, 0, 0.5);
    }

    .welcome-message h2 {
        font-size: 30px;
        font-weight: bold;
        color: #FFA500;
        text-shadow: 2px 2px 5px black;
    }

    .welcome-message p {
        font-size: 18px;
        color: #fff;
        font-weight: 500;
        margin-top: 15px;
    }

    .main-content {
        display: flex;
        justify-content: center;
        align-items: flex-start;
        gap: 20px;
        margin-top: 40px;
        flex-wrap: wrap;
    }

    .promo-box, .event-box {
        width: 220px;
        background: rgba(0, 0, 0, 0.6);
        padding: 15px;
        border-radius: 10px;
        color: #fff;
        box-shadow: 0 0 15px rgba(255, 165, 0, 0.4);
    }

    .promo-box h3, .event-box h3, .delivery-box h3 {
        color: #FFD700;
        font-size: 20px;
        margin-bottom: 10px;
        text-align: center;
        text-shadow: 1px 1px 3px black;
    }

    .promo-box ul, .event-box ul, .delivery-box ul {
        list-style: none;
        padding: 0;
        font-size: 14px;
    }

    .promo-box li, .event-box li, .delivery-box li {
        margin-bottom: 10px;
        padding: 8px;
        background: rgba(255,255,255,0.05);
        border-radius: 6px;
    }

    .slideshow-container {
        position: relative;
        width: 500px;
        height: 250px;
        overflow: hidden;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
    }

    .slide { display: none; width: 100%; height: 100%; }
    .slide img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 10px;
    }

    .fade { animation: fadeEffect 1.5s ease-in-out; }
    @keyframes fadeEffect {
        from { opacity: 0.4; }
        to { opacity: 1; }
    }

    .bottom-section {
        display: flex;
        justify-content: center;
        align-items: flex-start;
        gap: 20px;
        margin-top: 40px;
        flex-wrap: wrap;
    }

    .delivery-box {
        background: rgba(0, 0, 0, 0.6);
        padding: 20px;
        border-radius: 10px;
        width: 300px;
        color: #fff;
        box-shadow: 0 0 10px rgba(255, 165, 0, 0.3);
    }

    .jobcafe-box {
        background: linear-gradient(135deg, #ff9933, #ffcc66);
        padding: 20px;
        border-radius: 10px;
        width: 300px;
        color: #fff;
        text-align: center;
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
    }

    .jobcafe-box h3 {
        font-size: 22px;
        margin-bottom: 15px;
    }

    .jobcafe-box a {
        color: #fff;
        background: rgba(0,0,0,0.2);
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        font-weight: bold;
        display: inline-block;
        margin-top: 10px;
    }

    .jobcafe-box a:hover {
        background: rgba(0,0,0,0.4);
    }

    .applicants-box {
        background: linear-gradient(135deg, #00b4d8, #90e0ef);
        padding: 20px;
        border-radius: 10px;
        width: 300px;
        color: #fff;
        text-align: center;
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
    }

    .applicants-box h3 {
        font-size: 22px;
        margin-bottom: 15px;
    }

    .applicants-box a {
        color: #fff;
        background: rgba(0,0,0,0.2);
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        font-weight: bold;
        display: inline-block;
        margin-top: 10px;
    }

    .applicants-box a:hover {
        background: rgba(0,0,0,0.4);
    }

    footer {
        background: black;
        color: white;
        padding: 20px;
        text-align: center;
        margin-top: auto;
    }

    @media screen and (max-width: 900px) {
        .main-content, .bottom-section {
            flex-direction: column;
            align-items: center;
        }

        .promo-box, .event-box, .delivery-box, .jobcafe-box, .applicants-box {
            width: 90%;
        }

        .slideshow-container {
            width: 100%;
            max-width: 500px;
        }
    }
</style>
</head>

<body>

<?php include 'header.php'; ?>

<div class="container">
    <div class="welcome-message">
        <?php if (isset($_SESSION['username'])): ?>
            <h2>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>! 👋</h2>
            <p>Your cravings are calling — grab your favorites now and satisfy that hunger!</p>
        <?php else: ?>
            <h2>Welcome to <span style="color: #FFD700;">Job & Grab</span>! </h2>
            <p>Discover mouthwatering dishes, explore irresistible flavors, and grab your next meal with ease!</p>
        <?php endif; ?>
    </div>

    <div class="main-content">
        <div class="promo-box">
            <h3>🔥 Promos</h3>
            <ul>
                <li>Buy 1 Take 1 Dinuguan!</li>
                <li>Free orders over ₱300</li>
                <li>20% off on all desserts</li>
            </ul>
        </div>

        <div class="slideshow-container">
            <div class="slide fade"><img src="images/appetizer.jpg" alt="Appetizers"></div>
            <div class="slide fade"><img src="images/mainC.jpg" alt="Main Course"></div>
            <div class="slide fade"><img src="images/sweet.jpg" alt="Desserts"></div>
        </div>

        <div class="event-box">
            <h3>📅 Events</h3>
            <ul>
                <li>🎉 Customer Day – July 15</li>
                <li>🎤 Karaoke Night – Fridays</li>
                <li>🍽️ Taste Test – Aug 3–4</li>
            </ul>
        </div>
    </div>

    <div class="bottom-section">
        <div class="delivery-box">
            <h3>🚚 Delivery Zones</h3>
            <ul>
                <li>📍 Manila</li>
                <li>📍 Quezon City</li>
                <li>📍 Makati</li>
                <li>📍 Pasig</li>   
                <li>📍 Laguna</li>
            </ul>
        </div>
            
       
    </div>
</div>

<footer>
    <p>&copy; 2025 Job & Grab. All rights reserved.</p>
</footer>

<script>
    let slideIndex = 0;
    function showSlides() {
        let slides = document.getElementsByClassName("slide");
        for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) { slideIndex = 1; }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 3000);
    }
    showSlides();
</script>

</body>
</html>
