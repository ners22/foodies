<?php
$host = 'localhost';
$user = 'root';  // Default for XAMPP
$password = '';  // Default is empty in XAMPP
$database = 'system_food';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8");
?>
