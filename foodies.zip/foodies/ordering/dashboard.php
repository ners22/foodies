<?php
session_start();
include('config.php'); // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// Fetch food items from the menu table
$sql = "SELECT * FROM menu WHERE 1";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Foodies</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Nunito', sans-serif; background: url('imahe/mama.jpg') no-repeat center center fixed; background-size: cover; color: #333; margin: 0; }
        .container {
            max-width: 1100px;
            margin: 40px auto 0 auto;
            padding: 30px 20px 20px 20px;
            background: rgba(255,255,255,0.95);
            box-shadow: 0px 4px 24px rgba(0,0,0,0.13);
            border-radius: 16px;
            text-align: center;
        }
        h2 { margin-bottom: 10px; color: #ff8800; }
        .food-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 24px;
            margin-top: 30px;
        }
        .food-card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(255, 136, 0, 0.08);
            padding: 18px 14px 20px 14px;
            display: flex;
            flex-direction: column;
            align-items: center;
            transition: box-shadow 0.2s;
        }
        .food-card:hover {
            box-shadow: 0 6px 24px rgba(255, 136, 0, 0.18);
        }
        .food-card img {
            width: 100%;
            max-width: 210px;
            height: 140px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        .food-card h3 {
            font-size: 20px;
            margin: 8px 0 4px 0;
            color: #ff8800;
        }
        .food-card .category {
            font-size: 13px;
            color: #888;
            margin-bottom: 6px;
        }
        .food-card .desc {
            font-size: 14px;
            color: #444;
            margin-bottom: 10px;
            min-height: 36px;
        }
        .food-card .price {
            font-size: 18px;
            color: #28a745;
            font-weight: bold;
            margin-bottom: 8px;
        }
        .food-card .status {
            font-size: 13px;
            color: #fff;
            background: #28a745;
            border-radius: 5px;
            padding: 2px 10px;
            margin-bottom: 10px;
            display: inline-block;
        }
        .food-card .status.unavailable {
            background: #d9534f;
        }
        .food-card button {
            background: #ff8800;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 10px 22px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s;
        }
        .food-card button:hover {
            background: #ff6600;
        }
        .cart-feedback {
            color: #28a745;
            font-size: 15px;
            margin-top: 10px;
            display: none;
        }
        @media (max-width: 600px) {
            .container { padding: 10px; }
            .food-card img { max-width: 100%; height: 120px; }
        }
    </style>
    <script>
    function addToCart(id, name, price) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'add_to_cart.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                document.getElementById('cart-feedback-' + id).style.display = 'block';
                setTimeout(function() {
                    document.getElementById('cart-feedback-' + id).style.display = 'none';
                }, 1200);
                // Optionally update cart count in header
                var badge = document.querySelector('.icon-badge');
                if (badge) badge.textContent = xhr.responseText;
            }
        };
        xhr.send('id=' + encodeURIComponent(id) + '&name=' + encodeURIComponent(name) + '&price=' + encodeURIComponent(price) + '&quantity=1');
    }
    </script>
</head>
<body>

<?php include('header.php'); ?>

<div class="container">
    <h2>Welcome, <?php echo htmlspecialchars($username); ?>! 🍔</h2>
    <h3>Available Foods</h3>
    <div class="food-grid">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $img = htmlspecialchars($row['image'] ?? '');
                $name = htmlspecialchars($row['name']);
                $desc = htmlspecialchars($row['description']);
                $cat = htmlspecialchars($row['category']);
                $price = number_format($row['price'], 2);
                $status = (isset($row['status']) && $row['status'] === 'unavailable') ? 'unavailable' : 'available';
                echo '<div class="food-card">';
                if ($img) {
                    echo '<img src="' . $img . '" alt="' . $name . '">';
                } else {
                    echo '<img src="images/foodBg.jpg" alt="Food">';
                }
                echo '<h3>' . $name . '</h3>';
                echo '<div class="category">' . ($cat ? $cat : 'Other') . '</div>';
                echo '<div class="desc">' . $desc . '</div>';
                echo '<div class="price">₱' . $price . '</div>';
                echo '<span class="status ' . $status . '">' . ucfirst($status) . '</span>';
                if ($status === 'available') {
                    echo '<button onclick="addToCart(' . $row['id'] . ', \'" . addslashes($row['name']) . "\', ' . $row['price'] . ')">Add to Cart</button>';
                } else {
                    echo '<button disabled>Unavailable</button>';
                }
                echo '<div class="cart-feedback" id="cart-feedback-' . $row['id'] . '">Added to cart!</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No foods available.</p>';
        }
        ?>
    </div>
</div>

</body>
</html>
