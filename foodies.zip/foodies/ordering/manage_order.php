<?php
require_once 'config.php'; // Database connection

// Handle updating order status
if (isset($_GET['mark_delivered'])) {
    $order_id = $_GET['mark_delivered'];
    $query = "UPDATE orders SET status = 'Delivered' WHERE id = '$order_id'";
    mysqli_query($conn, $query);
    header("Location: manage_orders.php"); // Refresh to reflect the change
    exit();
}

// Handle deleting an order
if (isset($_GET['delete'])) {
    $order_id = $_GET['delete'];
    $query = "DELETE FROM orders WHERE id = '$order_id'";
    mysqli_query($conn, $query);
    header("Location: manage_orders.php"); // Refresh to update table
    exit();
}

// Fetch orders from the database
$orders = mysqli_query($conn, "SELECT * FROM orders ORDER BY order_time DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #0f0f0f; color: #fff; font-family: Arial, sans-serif; }
        .navbar { background-color: #111; }
        .navbar-brand { color: #ffa31a !important; font-weight: bold; }
        .container { margin-top: 40px; background-color: #1a1a1a; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(255, 163, 26, 0.5); }
        .btn-orange { background-color: #ffa31a; color: #0f0f0f; font-weight: bold; }
        .btn-orange:hover { background-color: #ff8c00; color: #fff; }
        .btn-danger { background-color: #ff4d4d; border: none; }
        .btn-danger:hover { background-color: #cc0000; }
        .btn-back { background-color: #333; border: 1px solid #ffa31a; color: #ffa31a; }
        .btn-back:hover { background-color: #ffa31a; color: #000; }
        .table th { background-color: #222; color: #ffa31a; }
        tr:hover { background-color: #292929; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-dark">
    <div class="container-fluid d-flex justify-content-between">
        <a class="navbar-brand" href="#">Manage Orders</a>
        <a href="dashboard.php" class="btn btn-back">⬅️ Back to Dashboard</a>
    </div>
</nav>

<!-- Manage Orders Section -->
<div class="container">
    <h2 class="text-center mb-4">📦 Manage Orders</h2>

    <!-- Display Orders -->
    <table class="table table-dark table-hover text-center">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Food Item</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>Order Time</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = mysqli_fetch_assoc($orders)): ?>
                <tr>
                    <td><?= $order['id'] ?></td>
                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                    <td><?= htmlspecialchars($order['food_item']) ?></td>
                    <td><?= $order['quantity'] ?></td>
                    <td>₱<?= number_format($order['total_price'], 2) ?></td>
                    <td><?= $order['status'] ?></td>
                    <td><?= $order['order_time'] ?></td>
                    <td>
                        <!-- Mark Delivered Button -->
                        <?php if ($order['status'] !== 'Delivered'): ?>
                            <a href="manage_orders.php?mark_delivered=<?= $order['id'] ?>" class="btn btn-success btn-sm">✅ Mark as Delivered</a>
                        <?php endif; ?>
                        <!-- Delete Order Button -->
                        <a href="manage_orders.php?delete=<?= $order['id'] ?>" class="btn btn-danger btn-sm">❌ Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Bottom Go Back Button -->
    <button onclick="history.back()" class="btn btn-back w-100 mt-3">⬅️ Go Back</button>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
