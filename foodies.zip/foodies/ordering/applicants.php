<?php
session_start();
include 'C:/xampp1/htdocs/jobcafe/database/database.php';

$query = "SELECT 
            a.id AS application_id,
            a.application_date,
            a.status,
            u.username,
            u.email,
            j.job_title,
            j.company_name
          FROM applied a
          LEFT JOIN users u ON a.seeker_id = u.id
          LEFT JOIN jobs j ON a.applied_job = j.id
          ORDER BY a.application_date DESC";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Applicants List</title>
    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            padding: 20px;
        }
        .back-button {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background-color: #0077b6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        .back-button:hover {
            background-color: #005f8a;
        }
        table {
            width: 100%;
            background: #fff;
            border-collapse: collapse;
            box-shadow: 0 0 10px #ccc;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #0077b6;
            color: white;
        }
    </style>
</head>
<body>

    <a class="back-button" href="http://localhost/foodies/index.php">&larr; Back to Home</a>

    <h2>All Job Applicants</h2>

    <?php if ($result && $result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Applicant</th>
                <th>Email</th>
                <th>Job Title</th>
                <th>Company</th>
                <th>Status</th>
                <th>Applied On</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['username'] ?: 'No Name') ?></td>
                    <td><?= htmlspecialchars($row['email'] ?: 'No Email') ?></td>
                    <td><?= htmlspecialchars($row['job_title'] ?: 'No Title') ?></td>
                    <td><?= htmlspecialchars($row['company_name'] ?: 'No Company') ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td><?= date("F j, Y", strtotime($row['application_date'])) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No applicants found.</p>
    <?php endif; ?>
</body>
</html>
