<?php
session_start();

// Example total calculation
$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Food Ordering</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9f9f9;
            color: #333;
        }
        header {
            background-color: #ff5722;
            color: white;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        header h1 {
            font-size: 2.5rem;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            margin-bottom: 30px;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        table th {
            background-color: #fafafa;
        }
        table tr:hover {
            background-color: #f5f5f5;
        }
        .total {
            font-size: 1.5rem;
            font-weight: bold;
            margin-top: 20px;
            text-align: right;
        }
        button {
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.2rem;
            width: 100%;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #218838;
        }
        .footer {
            text-align: center;
            margin-top: 50px;
            font-size: 14px;
            color: #777;
        }
        .footer a {
            color: #ff5722;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            header h1 {
                font-size: 2rem;
            }
            .container {
                padding: 20px;
            }
            .total {
                font-size: 1.2rem;
            }
            button {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

<header>
    <h1>Checkout - Food Ordering</h1>
</header>

<div class="container">
    <h3>Your Cart</h3>

    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($_SESSION['cart'] as $item) {
                $item_total = $item['price'] * $item['quantity'];
            ?>
                <tr>
                    <td><?= htmlspecialchars($item['name']) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td>$<?= number_format($item['price'], 2) ?></td>
                    <td>$<?= number_format($item_total, 2) ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="total">
        <p>Total: $<?= number_format($total, 2) ?></p>
    </div>

    <form method="POST">
        <button type="submit" name="confirm_order">Confirm Order</button>
    </form>
</div>

<div class="footer">
    <p>Thank you for ordering with us! <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
</div>

</body>
</html>
