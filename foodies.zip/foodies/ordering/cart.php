<?php
session_start();

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

foreach ($_SESSION['cart'] as $key => $item) {
    if (!is_array($item) || !isset($item['name'], $item['price'], $item['quantity'])) {
        unset($_SESSION['cart'][$key]);
    }
}

$cart_items = $_SESSION['cart'];
$total_price = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>

    <!-- Google Font: Dancing Script -->
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            text-align: center;
            background: url("imahe/mama.jpg") no-repeat center center fixed;
            background-size: cover;
            color: white;
            padding: 20px;
        }

        .cart-container {
            max-width: 700px;
            margin: auto;
            padding: 25px;
            background: rgba(0, 0, 0, 0.85);
            border-radius: 16px;
            box-shadow: 0 0 30px rgba(255, 153, 0, 0.6);
            transition: all 0.3s ease-in-out;
        }

        h1 {
            font-family: 'Dancing Script', cursive;
            font-size: 48px;
            color: #ffcc00;
            text-shadow: 2px 2px 8px black;
        }

        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #222;
            padding: 15px;
            margin: 12px 0;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(255, 153, 0, 0.2);
            transition: transform 0.2s;
        }

        .cart-item:hover {
            transform: scale(1.01);
        }

        .item-name {
            flex: 2;
            text-align: left;
            font-weight: bold;
            font-size: 18px;
        }

        .item-controls {
            display: flex;
            align-items: center;
            gap: 6px;
            margin-right: 20px; /* Add spacing between controls and price */
        }

        .item-price {
            flex: 1;
            text-align: right;
            display: flex;
            align-items: center;
            gap: 10px; /* Wider spacing between ₱ and value */
            font-size: 17px;
        }

        .quantity-btn {
            background: #ff9900;
            color: black;
            padding: 5px 12px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }

        .quantity-btn:hover {
            background: #ffa733;
        }

        .quantity-input {
            width: 50px;
            text-align: center;
            background: #111;
            color: white;
            border: 1px solid #ff9900;
            border-radius: 6px;
            font-size: 16px;
        }

        .remove-btn {
            background: crimson;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 5px 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            transition: background 0.3s;
        }

        .remove-btn:hover {
            background: darkred;
        }

        .btn-group {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 25px;
        }

        .checkout-btn, .menu-btn {
            flex: 1 1 48%;
            padding: 14px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.2s ease-in-out;
        }

        .checkout-btn {
            background: #00ff9c;
            color: black;
        }

        .checkout-btn:hover {
            transform: scale(1.05);
        }

        .menu-btn {
            background: #ffcc00;
            color: black;
        }

        .menu-btn:hover {
            transform: scale(1.05);
        }

        .cancel-btn.cancel-separate {
            width: 100%;
            margin-top: 15px;
            padding: 14px;
            font-size: 16px;
            font-weight: bold;
            background: red;
            color: white;
            border: none;
            border-radius: 10px;
            transition: background 0.3s, transform 0.2s ease-in-out;
        }

        .cancel-btn.cancel-separate:hover {
            background: darkred;
            transform: scale(1.03);
        }

        .cart-count {
            position: absolute;
            top: 20px;
            right: 20px;
            background: crimson;
            color: white;
            border-radius: 50%;
            font-size: 14px;
            font-weight: bold;
            padding: 8px 12px;
            box-shadow: 0 0 10px red;
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        @media screen and (max-width: 600px) {
            .cart-item {
                flex-direction: column;
                align-items: flex-start;
            }

            .item-price, .item-controls {
                margin-top: 8px;
                text-align: left;
            }

            .btn-group {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>

<h1>Your Shopping Cart</h1>
<span class="cart-count" id="cart-count"><?= array_sum(array_column($cart_items, 'quantity')) ?></span>

<div class="cart-container">
<?php if (empty($cart_items)): ?>
    <p>Your cart is empty.</p>
<?php else: ?>
    <?php foreach ($cart_items as $index => $item): 
        if (!is_array($item)) continue;
        $subtotal = $item['price'] * $item['quantity'];
        $total_price += $subtotal;
    ?>
    <div class="cart-item">
        <div class="item-name">
            <?= htmlspecialchars($item['name']) ?> (₱<?= number_format($item['price'], 2) ?>)
        </div>
        <div class="item-controls">
            <button class="quantity-btn" onclick="changeQuantity(<?= $index ?>, -1)">-</button>
            <input type="number" id="qty-<?= $index ?>" class="quantity-input" value="<?= $item['quantity'] ?>" min="1" onchange="manualUpdate(<?= $index ?>)">
            <button class="quantity-btn" onclick="changeQuantity(<?= $index ?>, 1)">+</button>
        </div>
        <div class="item-price">
            ₱<span id="sub-<?= $index ?>"><?= number_format($subtotal, 2) ?></span>
            <button class="remove-btn" onclick="removeItem(<?= $index ?>)">X</button>
        </div>
    </div>
    <?php endforeach; ?>
    <h3>Total: ₱<span id="total-price"><?= number_format($total_price, 2) ?></span></h3>

    <div class="btn-group">
        <button class="checkout-btn" onclick="checkout()">Checkout</button>
        <button class="menu-btn" onclick="goMenu()">Back to Menu</button>
    </div>

    <button class="cancel-btn cancel-separate" onclick="cancelCart()">Cancel Order</button>
<?php endif; ?>
</div>

<script>
function changeQuantity(index, change) {
    const qtyInput = document.getElementById('qty-' + index);
    let quantity = parseInt(qtyInput.value) + change;
    if (quantity < 1) quantity = 1;
    qtyInput.value = quantity;
    updateCart(index, quantity);
}

function manualUpdate(index) {
    const qtyInput = document.getElementById('qty-' + index);
    let quantity = parseInt(qtyInput.value);
    if (isNaN(quantity) || quantity < 1) {
        quantity = 1;
        qtyInput.value = 1;
    }
    updateCart(index, quantity);
}

function updateCart(index, quantity) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "update_cart.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onload = function () {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            document.getElementById('sub-' + index).innerText = parseFloat(response.subtotal).toFixed(2);
            document.getElementById('total-price').innerText = parseFloat(response.total_price).toFixed(2);
            document.getElementById('cart-count').innerText = response.total_quantity;
            if (response.reload) {
                window.location.reload();
            }
        }
    };
    xhr.send(`index=${index}&quantity=${quantity}`);
}

function removeItem(index) {
    if (confirm("Remove this item from cart?")) {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "remove_item.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onload = function () {
            if (xhr.status === 200) {
                window.location.reload();
            }
        };
        xhr.send(`index=${index}`);
    }
}

function checkout() {
    alert("Thank you for your purchase!");
    window.location.href = "checkout.php";
}

function goMenu() {
    window.location.href = "menu.php";
}

function cancelCart() {
    if (confirm("Are you sure you want to cancel your order?")) {
        window.location.href = "cancel_cart.php";
    }
}
</script>

</body>
</html>
