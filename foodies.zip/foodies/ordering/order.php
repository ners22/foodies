<?php
session_start();
include __DIR__ . '/db.php'; // Make sure db.php exists in the same directory

// Redirect to login if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Fetch user info
$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'] ?? 0; // Default sa 0 kung wala

// Fetch cart from session
$cart = $_SESSION['cart'] ?? [];
$total_price = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart));

// Process order
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($cart)) {
    if (!isset($_POST['address']) || empty($_POST['address'])) {
        echo "<script>alert('Please enter an address.');</script>";
    } else {
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method'] ?? 'COD');

        $items_json = json_encode($cart);
        $sql = "INSERT INTO orders (user_id, items, total_price, address, payment_method, order_date) 
                VALUES ('$user_id', '$items_json', '$total_price', '$address', '$payment_method', NOW())";

        if (mysqli_query($conn, $sql)) {
            unset($_SESSION['cart']); // Clear cart after order
            echo "<script>alert('Order placed successfully!'); window.location.href='menu.php';</script>";
        } else {
            echo "<script>alert('Error placing order: " . mysqli_error($conn) . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foodies - Checkout</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: #181818; color: white; display: flex; flex-direction: column; align-items: center; min-height: 100vh; }
        .container { width: 90%; max-width: 600px; text-align: center; padding: 20px; background: #222; border-radius: 10px; margin-top: 50px; }
        h2 { color: #ff9900; }
        .cart-items { margin: 20px 0; }
        .cart-item { display: flex; justify-content: space-between; background: #333; padding: 10px; margin-bottom: 10px; border-radius: 5px; }
        form { display: flex; flex-direction: column; }
        input, select, button { margin-top: 10px; padding: 10px; border-radius: 5px; border: none; font-size: 16px; }
        input { background: #fff; }
        button { background: #ff9900; color: black; font-weight: bold; cursor: pointer; transition: 0.3s; }
        button:hover { background: #e68a00; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Checkout</h2>

        <?php if (empty($cart)): ?>
            <p>Your cart is empty. <a href="menu.php" style="color: #ff9900;">Go to menu</a></p>
        <?php else: ?>
            <div class="cart-items">
                <?php foreach ($cart as $item): ?>
                    <div class="cart-item">
                        <span><?php echo htmlspecialchars($item['name']); ?> (x<?php echo $item['quantity']; ?>)</span>
                        <span>₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <h3>Total: ₱<?php echo number_format($total_price, 2); ?></h3>

            <form method="POST">
                <input type="text" name="address" placeholder="Enter delivery address" required>
                <select name="payment_method" required>
                    <option value="COD">Cash on Delivery (COD)</option>
                    <option value="Gcash">Gcash</option>
                </select>
                <button type="submit">Place Order</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
