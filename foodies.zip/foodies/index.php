<?php
// Redirect to the ordering subdirectory
header("Location: ordering/index.php");
exit();
?>
